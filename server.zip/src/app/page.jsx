"use client";
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";

// import required modules
import {
  Autoplay,
  Pagination,
  Navigation,
  A11y,
  Controller,
  Thumbs,
} from "swiper/modules";
import { useState } from "react";
import Messenger from "./components/Messenger";

export default function Home() {
  const [controlledSwiper, setControlledSwiper] = useState(null);
  const [thumbsSwiper, setThumbsSwiper] = useState(null);

  return (
    <>
      <div className="main">
        <Messenger />
        <div className="sli">
          <Swiper
            modules={[Thumbs]}
            watchSlidesProgress
            onSwiper={setThumbsSwiper}
            className="mySwiper"
          >
            <SwiperSlide>Slide 1</SwiperSlide>
            <SwiperSlide>Slide 2</SwiperSlide>
            <SwiperSlide>Slide 3</SwiperSlide>
            <SwiperSlide>Slide 4</SwiperSlide>
            <SwiperSlide>
              {({ isActive }) => (
                <div>Current slide is {isActive ? "active" : "not active"}</div>
              )}
            </SwiperSlide>
          </Swiper>
          <div className="sli-center">
            <Swiper
              slidesPerView="auto"
              breakpoints={{
                1024: {
                  slidesPerView: 3,
                  // spaceBetween: ,
                },
              }}
              spaceBetween={10}
              loop={true}
              centeredSlides={true}
              pagination={{
                clickable: true,
              }}
              autoplay={{
                delay: 2500,
                disableOnInteraction: false,
              }}
              // controller={{ control: controlledSwiper }}
              thumbs={{ swiper: thumbsSwiper }}
              modules={[Autoplay, Pagination, Thumbs]}
              className="mySwiper"
            >
              <SwiperSlide>Slide 1</SwiperSlide>
              <SwiperSlide>Slide 2</SwiperSlide>
              <SwiperSlide>Slide 3</SwiperSlide>
              <SwiperSlide>Slide 4</SwiperSlide>
              <SwiperSlide>
                {({ isActive }) => (
                  <div>
                    Current slide is {isActive ? "active" : "not active"}
                  </div>
                )}
              </SwiperSlide>
            </Swiper>
          </div>
        </div>
      </div>
    </>
  );
}
