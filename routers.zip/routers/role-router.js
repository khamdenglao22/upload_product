const RoleController = require("../controllers/role-controller");

const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

// router
router.get("/", getCurrentUser, RoleController.findAllRole);
router.get("/:id", getCurrentUser, RoleController.findRoleById);
router.post("/", getCurrentUser, RoleController.createRole);
router.put("/:id", getCurrentUser, RoleController.updateRole);
router.delete("/:id", getCurrentUser, RoleController.deleteRole);

module.exports = router;
