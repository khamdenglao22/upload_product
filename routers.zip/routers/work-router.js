const WorkController = require("../controllers/work-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/", WorkController.findAllWork);
router.get("/:id", WorkController.findWorkById);
router.put("/:id", getCurrentUser, WorkController.updateWork);
router.delete("/:id", getCurrentUser, WorkController.deleteWork);
router.post("/", getCurrentUser, WorkController.createWork);

module.exports = router;
