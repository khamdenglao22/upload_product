const serviceCountController = require("../controllers/service-country-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/", serviceCountController.findAllServiceCountry);
router.get("/:id", serviceCountController.findServiceCountryById);
router.put("/:id", getCurrentUser, serviceCountController.updateServiceCountry);
router.delete(
  "/:id",
  getCurrentUser,
  serviceCountController.deleteServiceCountry
);
router.post("/", getCurrentUser, serviceCountController.createServiceCountry);

module.exports = router;
