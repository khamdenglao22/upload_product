const ServiceLocationController = require("../controllers/service-location-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/", ServiceLocationController.findAllLocation);
router.get("/:id", ServiceLocationController.findLocationById);
router.put("/:id",getCurrentUser, ServiceLocationController.updateLocation);
router.delete("/:id",getCurrentUser, ServiceLocationController.deleteLocation);
router.post("/",getCurrentUser, ServiceLocationController.createLocation);

router.post("/prov_country", ServiceLocationController.findByProvAndCountry);
router.post(
  "/section_country",
  ServiceLocationController.findByProvAndSectionId
);

module.exports = router;
