const villageController = require("../controllers/village-controller");

const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/", villageController.findAllVillage);
router.post("/", getCurrentUser, villageController.createVillage);
router.get("/:id", villageController.findVillageById);
router.put("/:id", getCurrentUser, villageController.updateVillage);

module.exports = router;
