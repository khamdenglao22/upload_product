const bannerController = require("../controllers/banner-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/", getCurrentUser, bannerController.FindAllBanner);
router.get("/page", bannerController.findAllBannerActive);
router.post("/", getCurrentUser, bannerController.createNewBanner);
router.put("/:id", getCurrentUser, bannerController.updateBanner);
router.put(
  "/update-active/:id",
  getCurrentUser,
  bannerController.updateBannerActive
);
router.get("/:id", getCurrentUser, bannerController.findBannerById);
router.delete("/:id", getCurrentUser, bannerController.deleteBanner);

module.exports = router;
