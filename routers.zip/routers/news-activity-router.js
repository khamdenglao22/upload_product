const NewsActivityController = require("../controllers/news-activity-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/", NewsActivityController.findAllNewsActivity);
router.get(
  "/all-back-office",
  getCurrentUser,
  NewsActivityController.findAllNewsActiveBackOffice
);
router.get("/active", NewsActivityController.findAllNewsActive);
router.get("/:id", NewsActivityController.findNewsActivityById);
router.put("/:id", getCurrentUser, NewsActivityController.updateNewsActivity);
router.put(
  "/update-active/:id",
  getCurrentUser,
  NewsActivityController.updateNewsActive
);
router.delete(
  "/:id",
  getCurrentUser,
  NewsActivityController.deleteNewsActivity
);
router.post("/", getCurrentUser, NewsActivityController.createNews);

module.exports = router;
