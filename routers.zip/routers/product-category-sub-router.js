const ProductCategorySubController = require("../controllers/product-category-sub-controller")
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get('/',ProductCategorySubController.findAllProductCategorySub)
router.post('/',getCurrentUser,ProductCategorySubController.createProductCategorySub)
router.put('/:id',getCurrentUser,ProductCategorySubController.updateProductCategorySub)
router.get('/onChange/:id',ProductCategorySubController.findAllOnChangeCategorySub)
router.get('/:id',ProductCategorySubController.findProductCategorySubById)
router.delete('/:id',getCurrentUser,ProductCategorySubController.deleteProductCategorySub)

module.exports = router