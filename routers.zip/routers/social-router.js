const socialController = require("../controllers/social-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/", socialController.FindAllSocial);
router.post("/", getCurrentUser, socialController.createNewSocial);
router.put("/:id", getCurrentUser, socialController.updateSocial);
router.get("/:id", socialController.findSocialById);
router.delete("/:id", getCurrentUser, socialController.deleteSocial);

module.exports = router;
