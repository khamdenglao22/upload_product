const Product = require("../controllers/product-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/", Product.findAllProduct);
router.get("/Bof", Product.findProductBySubCateId);
router.post("/", getCurrentUser, Product.createProduct);
router.put("/:id", getCurrentUser, Product.updateProduct);
router.get("/:id", Product.findProductById);
router.delete("/:id", getCurrentUser, Product.deleteProduct);

module.exports = router;
