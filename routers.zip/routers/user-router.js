const UserController = require("../controllers/user-controller");

const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

// router
router.get("/", getCurrentUser, UserController.findAllUser);
// router.get('/role', UserController.findAllRole)
router.get("/:id", getCurrentUser, UserController.findUserById);
router.post("/", getCurrentUser, UserController.createUser);
router.put(
  "/change-password/:id",
  getCurrentUser,
  UserController.changePassword
);
router.put("/:id", getCurrentUser, UserController.updateUserById);
router.delete("/:id", getCurrentUser, UserController.deleteUserById);

module.exports = router;
