const serviceTypeController = require("../controllers/services-type-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/", serviceTypeController.findAllServicesType);
router.get("/:id", serviceTypeController.findServicesTypeById);
router.post("/", getCurrentUser, serviceTypeController.createServicesType);
router.put("/:id", getCurrentUser, serviceTypeController.updateServicesType);
router.delete("/:id", getCurrentUser, serviceTypeController.deleteServicesType);

module.exports = router;
