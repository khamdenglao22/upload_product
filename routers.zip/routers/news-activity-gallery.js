const NewsActivityGalleryController = require("../controllers/news-activity-gallery-controller")
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/:id",getCurrentUser, NewsActivityGalleryController.findByNewsActivityGalleryId)
router.delete("/:id",getCurrentUser, NewsActivityGalleryController.deleteNewsActivityGallery)
router.post("/",getCurrentUser, NewsActivityGalleryController.createNewsGallery)

module.exports = router;