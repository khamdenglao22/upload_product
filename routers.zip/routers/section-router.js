const ServiceSection = require("../controllers/section-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/", ServiceSection.findAllSection);
router.get("/frontend", ServiceSection.findAllSectionFrontend);
router.get("/:id", ServiceSection.findSectionById);
router.put("/:id", getCurrentUser, ServiceSection.updateSection);
router.delete("/:id", getCurrentUser, ServiceSection.deleteSection);
router.post("/", getCurrentUser, ServiceSection.createSection);

module.exports = router;
