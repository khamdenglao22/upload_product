const aboutStructureController = require("../controllers/about-structure-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/",getCurrentUser, aboutStructureController.FindAllAboutStructure);
router.get("/page/", aboutStructureController.FindAllPageAboutStructure);
router.post("/",getCurrentUser, aboutStructureController.createNewAboutStructure);
router.put("/:id",getCurrentUser, aboutStructureController.updateAboutStructure);
router.get("/:id",getCurrentUser, aboutStructureController.findAboutStructureById);
router.delete("/:id",getCurrentUser, aboutStructureController.deleteStructureById);

module.exports = router;
