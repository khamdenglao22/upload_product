const bannerAdvertising = require("../controllers/banner-advertising-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/", getCurrentUser, bannerAdvertising.FindAllBannerAdvertising);
router.get("/active", bannerAdvertising.findAllBannerAdvertisingActive);
router.post("/", getCurrentUser, bannerAdvertising.createNewBannerAdvertising);
router.put("/:id", getCurrentUser, bannerAdvertising.updateBannerAdvertising);
router.put(
  "/update-active/:id",
  getCurrentUser,
  bannerAdvertising.updateBannerAdvertisingActive
);
router.get("/:id", getCurrentUser, bannerAdvertising.findBannerAdvertisingById);
router.delete(
  "/:id",
  getCurrentUser,
  bannerAdvertising.deleteBannerAdvertising
);

module.exports = router;
