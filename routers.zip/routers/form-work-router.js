const {
  findAllFormWork,
  createFormWork,
  findFormWorkById,
  updateFormWork,
  deleteFormWorkById,
  updateFormWorkActive,
  findFormWorkActive,
} = require("../controllers/form-work-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/customer/", findFormWorkActive);
router.get("/", getCurrentUser, findAllFormWork);
router.post("/", getCurrentUser, createFormWork);
router.put("/:id", getCurrentUser, updateFormWork);
router.get("/:id", getCurrentUser, findFormWorkById);
router.put("/update-active/:id", getCurrentUser, updateFormWorkActive);
router.delete("/:id", getCurrentUser, deleteFormWorkById);

module.exports = router;
