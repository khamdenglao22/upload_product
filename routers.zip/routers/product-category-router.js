const ProductCategoryController = require("../controllers/product-category-controller");
const router = require("express").Router();
const { getCurrentUser } = require("../controllers/auth-controller");

router.get("/", ProductCategoryController.findAllProductCategory);
router.post(
  "/",
  getCurrentUser,
  ProductCategoryController.createProductCategory
);
router.put(
  "/:id",
  getCurrentUser,
  ProductCategoryController.updateProductCategory
);
router.get("/:id", ProductCategoryController.findProductCategoryById);
router.delete(
  "/:id",
  getCurrentUser,
  ProductCategoryController.deleteProductCategory
);

module.exports = router;
