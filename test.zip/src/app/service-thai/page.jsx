import React from "react";

export const metadata = {
  title: "service title",
  description: "description service",
};

function page() {
  return (
    <div>
      page product thai 
    </div>
  );
}

export default page;
