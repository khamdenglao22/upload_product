import "./globals.css";
// Import Swiper styles
import Header from "./components/Header";
import { ThemeModeScript } from "flowbite-react";
import axios from "axios";
import https from "https";

import "swiper/css";
import "swiper/css/navigation";
import Footer from "./components/Footer";

axios.defaults.httpsAgent = new https.Agent({
  rejectUnauthorized: false,
});

export const metadata = {
  title: "ST-Muang Thai Insurance",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link
          rel="icon"
          type="image/svg"
          href="/assets/images/logo.svg"
          sizes="any"
        />
        <link rel="stylesheet" href="/fonts/stylesheet.css" />
        <ThemeModeScript />
      </head>
      <body>
        <div className="container responsive">
          <Header />
          {children}
          <Footer />
        </div>
      </body>
    </html>
  );
}
