export const environment = {
    base_url : "https://www.stmuangthai.com/bof/api"
}

